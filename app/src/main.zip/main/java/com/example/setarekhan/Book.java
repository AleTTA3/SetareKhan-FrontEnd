
package com.example.setarekhan;

import java.io.Serializable;
import java.util.List;

public class Book implements Serializable {
    private String title;
    private String author;
    private String description;
    private int imageResId;
    private List<String> reviews;

    public Book(String title, String author, String description, int imageResId, List<String> reviews) {
        this.title = title;
        this.author = author;
        this.description = description;
        this.imageResId = imageResId;
        this.reviews = reviews;
    }

    public String getTitle() { return title; }
    public String getAuthor() { return author; }
    public String getDescription() { return description; }
    public int getImageResId() { return imageResId; }
    public List<String> getReviews() { return reviews; }
}
