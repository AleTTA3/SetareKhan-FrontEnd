
package com.example.setarekhan;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class BookDetailScreen extends AppCompatActivity {

    private TextView bookDetailTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_detail);

        bookDetailTitle = findViewById(R.id.bookDetailTitle);
        String bookTitle = getIntent().getStringExtra("bookTitle");

        bookDetailTitle.setText("جزئیات کتاب: " + bookTitle);
    }
}
