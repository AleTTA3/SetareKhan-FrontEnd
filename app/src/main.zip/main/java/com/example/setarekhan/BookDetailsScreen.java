
package com.example.setarekhan;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class BookDetailsScreen extends AppCompatActivity {
    TextView titleTextView, authorTextView, descriptionTextView, reviewsTextView;
    ImageView bookImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_details_screen);

        titleTextView = findViewById(R.id.book_title);
        authorTextView = findViewById(R.id.book_author);
        descriptionTextView = findViewById(R.id.book_description);
        reviewsTextView = findViewById(R.id.book_reviews);
        bookImage = findViewById(R.id.book_image);

        Book book = (Book) getIntent().getSerializableExtra("book");

        titleTextView.setText(book.getTitle());
        authorTextView.setText(book.getAuthor());
        descriptionTextView.setText(book.getDescription());
        reviewsTextView.setText(String.join("\n", book.getReviews()));
        bookImage.setImageResource(book.getImageResId());
    }
}
