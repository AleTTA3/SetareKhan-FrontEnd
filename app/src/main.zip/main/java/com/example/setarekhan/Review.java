package com.example.setarekhan;

import org.json.JSONException;
import org.json.JSONObject;

public class Review {
    private String userName;
    private double rating;
    private String review;

    public Review(String userName, double rating, String review) {
        this.userName = userName;
        this.rating = rating;
        this.review = review;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }

    // ✅ Convert JSON to Review object
    public static Review fromJson(JSONObject jsonObject) throws JSONException {
        String userName = jsonObject.getString("userName");
        double rating = jsonObject.getDouble("rating");
        String review = jsonObject.getString("review");
        return new Review(userName, rating, review);
    }

    // ✅ Convert Review object to JSON
    public JSONObject toJson() throws JSONException {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("userName", userName);
        jsonObject.put("rating", rating);
        jsonObject.put("review", review);
        return jsonObject;
    }
}
