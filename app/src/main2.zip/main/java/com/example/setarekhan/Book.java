
package com.example.setarekhan;

import java.io.Serializable;
import java.util.List;

public class Book implements Serializable {
    public String id;
    private String title;
    private String author;
    private String description;
    private int imageResId;

    private List<String> reviews;

    public Book(String title, String Id, String author, int imageResId, List<String> reviews) {
        this.title = title;
        this.id = id;
        this.author = author;
        this.description = description;
        this.imageResId = imageResId;
        this.reviews = reviews;
    }

    public String getTitle() { return title; }
    public String getAuthor() { return author; }
    public String getDescription() { return description; }
    public int getImageResId() { return imageResId; }

    public String getId() { return id;}
    public List<String> getReviews() { return reviews; }
}
