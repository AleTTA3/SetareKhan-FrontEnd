package com.example.setarekhan;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class BookDetailsScreen extends AppCompatActivity {

    TextView titleTextView, authorTextView, descriptionTextView;
    ImageView bookImage;
    RecyclerView reviewRecyclerView;

    ReviewAdapter reviewAdapter;
    List<Review> reviews = new ArrayList<>();
    Book book;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_details_screen);

        // اتصال ویوها
        titleTextView = findViewById(R.id.book_title);
        authorTextView = findViewById(R.id.book_author);
        descriptionTextView = findViewById(R.id.book_description);
        bookImage = findViewById(R.id.book_image);
        reviewRecyclerView = findViewById(R.id.review_recycler);

        // گرفتن داده‌های کتاب
        book = (Book) getIntent().getSerializableExtra("book");

        if (book != null) {
            titleTextView.setText(book.getTitle());
            authorTextView.setText(book.getAuthor());
            descriptionTextView.setText(book.getDescription());
            bookImage.setImageResource(book.getImageResId());

            setupReviewsRecycler();
            fetchReviewsFromServer();
        }
    }

    private void setupReviewsRecycler() {
        reviewRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        reviewAdapter = new ReviewAdapter(reviews);
        reviewRecyclerView.setAdapter(reviewAdapter);
    }

    private void fetchReviewsFromServer() {
        String url = "http://192.168.1.3:8000/kaka/review/book/" + book.id;

        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null,
                response -> {
                    parseReviewResponse(response);
                },
                error -> {
                    Log.e("Volley", "Error: " + error.toString());
                });

        Volley.newRequestQueue(this).add(request);
    }

    private void parseReviewResponse(JSONArray response) {
        reviews.clear();
        for (int i = 0; i < response.length(); i++) {
            try {
                JSONObject obj = response.getJSONObject(i);
                reviews.add(new Review(
                        obj.getString("userName"),
                        obj.getString("review"),
                        obj.getInt("rating")
                ));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        reviewAdapter.notifyDataSetChanged();
    }
}
