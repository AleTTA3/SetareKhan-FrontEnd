package com.example.setarekhan;

import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.view.Gravity;



public class MainActivity extends MenuBar {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout layout = new LinearLayout(this);
        layout.setGravity(Gravity.CENTER);
        layout.setBackgroundColor(Color.WHITE);
        TextView textView = new TextView(this);
        textView.setText("ایمان صادقی - صفحه اصلی");
        textView.setTextSize(30);
        textView.setTextColor(Color.BLACK);
        layout.addView(textView);
        setContentView(layout);
    }
}
