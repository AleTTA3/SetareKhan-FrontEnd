package com.example.setarekhan;

import android.content.Intent;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MenuBar extends AppCompatActivity {
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, 1, Menu.NONE, "خانه");
        menu.add(0, 2, Menu.NONE, "تنظیمات");
        menu.add(0, 3, Menu.NONE, "ورود");
        menu.add(0, 4, Menu.NONE, "ثبت نام");
        menu.add(0, 5, Menu.NONE, "پروفایل");
        menu.add(0, 6, Menu.NONE, "ماشین حساب");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case 1:
                Intent intent = new Intent(this, BookListScreen.class);
                startActivity(intent);
                Toast.makeText(this, "این خانه است", Toast.LENGTH_SHORT).show();
                return true;
            case 2:
                intent = new Intent(this, SettingsActivity.class);
                startActivity(intent);

                return true;
            case 3:
                intent = new Intent(this, LoginActivity.class);
                startActivity(intent);
                Toast.makeText(this, "این ورود است", Toast.LENGTH_SHORT).show();
                return true;
            case 4:
                intent = new Intent(this, SignUpActivity.class);
                startActivity(intent);
                Toast.makeText(this, "این ثبت نام است", Toast.LENGTH_SHORT).show();
                return true;
            case 5:
                intent = new Intent(this, ProfileActivity.class);
                startActivity(intent);
                Toast.makeText(this, "این پروفایل است", Toast.LENGTH_SHORT).show();
                return true;
            case 6:
                Toast.makeText(this, "این ماشین حساب است", Toast.LENGTH_SHORT).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}